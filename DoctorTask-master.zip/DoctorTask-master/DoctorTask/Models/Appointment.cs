﻿using System.ComponentModel.DataAnnotations;

namespace DoctorTask.Models
{
    public class Appointment
    {
        public int Id { get; set; }

        [Required]
        public string PatientName { get; set; } = string.Empty;

        [Required]
        public DateTime AppointmentDateTime { get; set; }

        public int DoctorId { get; set; }

        public Doctor Doctor { get; set; } = null!;
    }
}