﻿using DoctorTask.Data;
using DoctorTask.Models;
using DoctorTask.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DoctorTask.Controllers
{
    public class DoctorsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DoctorsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult BookAppointment(string? searchTerm, string? specialization)
        {
            var query = _context.Doctors
                .AsNoTracking()
                .AsQueryable();

            searchTerm = searchTerm?.Trim();
            specialization = specialization?.Trim();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                query = query.Where(d =>
                    EF.Functions.Like(d.Name, $"%{searchTerm}%"));
            }

            if (!string.IsNullOrWhiteSpace(specialization))
            {
                query = query.Where(d =>
                    EF.Functions.Like(d.Specialization, $"%{specialization}%"));
            }

            var vm = new DoctorSearchVM
            {
                SearchTerm = searchTerm,
                Specialization = specialization,
                Doctors = query.ToList()
            };

            return View(vm);
        }

        public IActionResult ReservationsManagement()
        {
            var reservations = _context.Appointments
                .Include(a => a.Doctor)
                .ToList();

            return View(reservations);
        }

        [HttpGet]
        public IActionResult CompleteAppointment(int id)
        {
            var doctor = _context.Doctors.Find(id);

            if (doctor == null)
                return NotFound();

            var vm = new CompleteAppointmentVM
            {
                DoctorId = doctor.Id,
                DoctorName = doctor.Name
            };

            return View(vm);
        }

        [HttpPost]
        public IActionResult CompleteAppointment(CompleteAppointmentVM vm)
        {
            var doctor = _context.Doctors.SingleOrDefault(d => d.Id == vm.DoctorId);
            if (doctor == null)
                return NotFound();

            if (!ModelState.IsValid)
            {
                vm.DoctorName = doctor.Name;
                return View(vm);
            }

            var dateTime = vm.Date.Date + vm.Time;

            if (dateTime < DateTime.Now)
            {
                ModelState.AddModelError("", "Cannot book an appointment in the past.");
                vm.DoctorName = doctor.Name;
                return View(vm);
            }

            var exists = _context.Appointments.Any(a =>
                a.DoctorId == vm.DoctorId &&
                a.AppointmentDateTime == dateTime);

            if (exists)
            {
                ModelState.AddModelError("", "This time slot is already booked.");
                vm.DoctorName = doctor.Name;
                return View(vm);
            }

            var appointment = new Appointment
            {
                DoctorId = vm.DoctorId,
                PatientName = vm.PatientName,
                AppointmentDateTime = dateTime
            };

            _context.Appointments.Add(appointment);
            _context.SaveChanges();

            return RedirectToAction("ReservationsManagement");
        }
    }
}