﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DoctorTask.Migrations
{
    /// <inheritdoc />
    public partial class SeedDataBase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                SET IDENTITY_INSERT Doctors ON;

                INSERT INTO Doctors (Id, Name, Specialization, ImageUrl)
                VALUES 
                (1, 'Dr. Ahmed Hassan', 'Cardiology', '/images/doctor1.jpg'),
                (2, 'Dr. Mohamed Ali', 'Dermatology', '/images/doctor2.jpg'),
                (3, 'Dr. Mostafa Adel', 'Neurology', '/images/doctor3.jpg'),
                (4, 'Dr. Karim Samy', 'Orthopedics', '/images/doctor4.jpg'),
                (5, 'Dr. Youssef Tarek', 'Pediatrics', '/images/doctor5.jpg'),
                (6, 'Dr. Omar Khaled', 'Dentistry', '/images/doctor6.jpg');

                SET IDENTITY_INSERT Doctors OFF;
            ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                DELETE FROM Doctors WHERE Id IN (1,2,3,4,5,6);
            ");
        }
    }
}
