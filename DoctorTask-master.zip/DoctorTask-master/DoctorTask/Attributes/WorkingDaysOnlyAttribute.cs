﻿using System.ComponentModel.DataAnnotations;

namespace DoctorTask.Attributes
{
    public class WorkingDaysOnlyAttribute : ValidationAttribute
    {
        public override bool IsValid(object? value)
        {
            if (value == null)
                return true;

            if (value is DateTime date)
            {
                return date.DayOfWeek != DayOfWeek.Friday &&
                       date.DayOfWeek != DayOfWeek.Saturday;
            }

            return false;
        }
    }
}