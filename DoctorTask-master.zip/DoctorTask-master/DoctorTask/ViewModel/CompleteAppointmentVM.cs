﻿using DoctorTask.Attributes;
using System.ComponentModel.DataAnnotations;

namespace DoctorTask.ViewModel
{
    public class CompleteAppointmentVM
    {
        public int DoctorId { get; set; }

        public string DoctorName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Patient name is required")]
        public string PatientName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Date is required")]
        [WorkingDaysOnly(ErrorMessage = "Doctors work only from Sunday to Thursday")]
        public DateTime Date { get; set; }

        [Required(ErrorMessage = "Time is required")]
        public TimeSpan Time { get; set; }
    }
}