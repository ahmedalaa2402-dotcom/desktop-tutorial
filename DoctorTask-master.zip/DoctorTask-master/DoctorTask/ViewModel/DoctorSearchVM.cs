﻿using DoctorTask.Models;

namespace DoctorTask.ViewModel
{
    public class DoctorSearchVM
    {
        public string? SearchTerm { get; set; }

        public string? Specialization { get; set; }

        public List<Doctor> Doctors { get; set; } = new();
    }
}
